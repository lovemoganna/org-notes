SELECT t.name
FROM (
  VALUES ('Alice'),
   ('Bob')
) AS t(name);
