SELECT DISTINCT ON (k) k, v
FROM (
  VALUES ('a', 2),
   ('a', 1),
   ('b', 3)
) t(k, v)
ORDER BY k, v;
