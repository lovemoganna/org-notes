CREATE TYPE mood AS ENUM('happy', 'sad');

CREATE TABLE people(id INTEGER, state mood);
