DESCRIBE people;
