SELECT schema_name, table_name FROM duckdb_tables() WHERE schema_name = 'analytics';
