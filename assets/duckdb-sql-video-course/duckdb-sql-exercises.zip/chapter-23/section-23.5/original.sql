CREATE SCHEMA analytics;

CREATE TABLE analytics.t(i INTEGER);
