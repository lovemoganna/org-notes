CREATE TABLE t AS SELECT *
FROM (
  VALUES (1, 'Alice'),
   (2, 'Bob')
) v(id, name);

SELECT *
FROM t
ORDER BY id;
