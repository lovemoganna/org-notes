SELECT bonus_calc(5000) AS bonus;
