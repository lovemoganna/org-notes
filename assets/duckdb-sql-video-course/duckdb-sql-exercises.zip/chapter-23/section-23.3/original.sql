CREATE MACRO bonus_calc(s) AS s * 0.15;

SELECT name, bonus_calc(salary) AS bonus
FROM (
  VALUES ('Alice', 5000)
) t(name, salary);
