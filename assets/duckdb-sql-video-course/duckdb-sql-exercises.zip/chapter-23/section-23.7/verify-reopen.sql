SELECT index_name FROM duckdb_indexes() WHERE table_name = 'idx_demo';
