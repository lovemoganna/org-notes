CREATE TABLE idx_demo(id INTEGER, name VARCHAR);

CREATE INDEX idx_demo_id ON idx_demo(id);
