CREATE VIEW v AS SELECT *
FROM (
  VALUES (1, 'Alice'),
   (2, 'Bob')
) t(id, name);

SELECT *
FROM v
ORDER BY id;
