SELECT nextval('id_seq') AS next_id;
