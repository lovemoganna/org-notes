CREATE SEQUENCE id_seq START 1;

SELECT nextval('id_seq') AS id;
