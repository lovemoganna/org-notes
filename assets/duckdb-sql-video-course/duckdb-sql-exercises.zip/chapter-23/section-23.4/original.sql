CREATE MACRO filter_by_min_sal(ms) AS TABLE
SELECT *
FROM (
  VALUES ('Alice', 5000),
   ('Bob', 7000)
) t(name, salary)
WHERE salary >= ms;

SELECT *
FROM filter_by_min_sal(6000);
