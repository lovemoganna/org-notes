SELECT * FROM filter_by_min_sal(6000);
