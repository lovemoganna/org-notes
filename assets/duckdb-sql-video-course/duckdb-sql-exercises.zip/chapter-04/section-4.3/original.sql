SELECT *
FROM (
  VALUES ('Alice', 'Sales', 5000),
   ('Charlie', 'Sales', 6000),
   ('Bob', 'Tech', 7000)
) t(name, dept, salary)
QUALIFY ROW_NUMBER() OVER (PARTITION BY dept
  ORDER BY salary DESC) = 1;
