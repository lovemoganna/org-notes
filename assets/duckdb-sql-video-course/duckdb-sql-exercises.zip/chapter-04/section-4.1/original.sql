SELECT *
FROM (
  VALUES (1, 'Alice', 5000),
   (2, 'Bob', 7000)
) t(id, name, salary)
WHERE salary >= 6000;
