SELECT dept, SUM(salary) AS total
FROM (
  VALUES ('Sales', 5000),
   ('Sales', 6000),
   ('Tech', 7000)
) t(dept, salary)
GROUP BY dept
HAVING SUM(salary) > 8000;
