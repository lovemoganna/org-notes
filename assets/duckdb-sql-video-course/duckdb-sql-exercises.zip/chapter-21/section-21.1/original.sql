SELECT l.t, r.v
FROM (
  VALUES (5),
   (10)
) l(t)
ASOF
LEFT JOIN (
  VALUES (3, 'a'),
   (8, 'b')
) r(t, v) ON l.t >= r.t
ORDER BY l.t;
