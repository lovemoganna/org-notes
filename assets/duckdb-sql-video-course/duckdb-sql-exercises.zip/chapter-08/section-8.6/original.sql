SELECT name, salary, LEAD(salary) OVER (
  ORDER BY salary) AS next_sal
FROM (
  VALUES ('Alice', 5000),
   ('Charlie', 6000),
   ('Bob', 7000)
) t(name, salary);
