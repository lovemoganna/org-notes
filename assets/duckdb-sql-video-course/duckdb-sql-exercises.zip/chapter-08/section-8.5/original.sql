SELECT name, salary, LAG(salary) OVER (
  ORDER BY salary) AS prev_sal, salary - LAG(salary) OVER (
  ORDER BY salary) AS diff
FROM (
  VALUES ('Alice', 5000),
   ('Charlie', 6000),
   ('Bob', 7000)
) t(name, salary);
