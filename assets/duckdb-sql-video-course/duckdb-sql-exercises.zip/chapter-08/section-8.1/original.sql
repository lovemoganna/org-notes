SELECT name, salary, SUM(salary) OVER (
  ORDER BY salary) AS run_sum
FROM (
  VALUES ('Alice', 5000),
   ('Bob', 7000)
) t(name, salary);
