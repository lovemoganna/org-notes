SELECT name, salary, RANK() OVER (
  ORDER BY salary DESC) AS rank_no
FROM (
  VALUES ('Alice', 6000),
   ('Bob', 7000),
   ('Charlie', 6000)
) t(name, salary);
