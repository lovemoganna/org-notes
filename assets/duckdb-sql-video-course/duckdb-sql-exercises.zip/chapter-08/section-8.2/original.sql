SELECT name, SUM(salary) OVER w, AVG(salary) OVER w
FROM (
  VALUES ('Alice', 5000),
   ('Bob', 7000)
) t(name, salary)
WINDOW w AS (
  ORDER BY salary);
