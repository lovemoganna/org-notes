SELECT name, dept, ROW_NUMBER() OVER (PARTITION BY dept
  ORDER BY salary DESC) AS seq
FROM (
  VALUES ('Alice', 'Sales', 5000),
   ('Charlie', 'Sales', 6000),
   ('Bob', 'Tech', 7000)
) t(name, dept, salary);
