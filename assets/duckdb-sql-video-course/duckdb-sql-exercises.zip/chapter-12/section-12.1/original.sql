SELECT *
FROM range(3) t(x);
