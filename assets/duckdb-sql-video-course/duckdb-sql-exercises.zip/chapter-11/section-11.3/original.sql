SELECT AVG(salary) AS avg_sal
FROM (
  SELECT salary
  FROM (
    VALUES (5000), (7000), (8000)
) t(salary)
  WHERE salary >= 6000
) s;
