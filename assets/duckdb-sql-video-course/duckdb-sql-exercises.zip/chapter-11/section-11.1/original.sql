WITH cte(x) AS (
  VALUES (1),
   (2)
)
SELECT *
FROM cte
ORDER BY x;
