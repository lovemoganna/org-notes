WITH high_pay AS (
  SELECT *
  FROM (
    VALUES ('Bob', 'Tech', 7000), ('David', 'Tech', 8000)
) t(name, dept, salary)
)
SELECT dept, COUNT(*)
FROM high_pay
GROUP BY dept;
