ATTACH ':memory:' AS aux2;

CREATE SCHEMA aux2.s;

USE aux2.s;

CREATE TABLE t(i INTEGER);

-- 补充检查
SELECT current_database() AS db, current_schema() AS schema_name;
