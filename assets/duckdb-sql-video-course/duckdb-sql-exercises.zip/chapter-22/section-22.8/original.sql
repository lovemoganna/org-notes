ATTACH ':memory:' AS aux2;

CREATE SCHEMA aux2.s;

USE aux2.s;

CREATE TABLE t(i INTEGER);
