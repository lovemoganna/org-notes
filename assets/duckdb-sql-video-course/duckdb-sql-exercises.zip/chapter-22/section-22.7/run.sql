ATTACH ':memory:' AS aux;

CREATE TABLE aux.t(i INTEGER);

SELECT *
FROM aux.t;

DETACH aux;

-- 补充检查
SELECT database_name FROM duckdb_databases() WHERE database_name = 'aux';
