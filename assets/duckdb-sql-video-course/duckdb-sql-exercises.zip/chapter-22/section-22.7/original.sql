ATTACH ':memory:' AS aux;

CREATE TABLE aux.t(i INTEGER);

SELECT *
FROM aux.t;

DETACH aux;
