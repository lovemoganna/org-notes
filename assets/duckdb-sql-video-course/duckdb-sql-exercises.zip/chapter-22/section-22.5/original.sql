CREATE TEMP SEQUENCE tmp_seq START 1;

SELECT nextval('tmp_seq') AS id;
