CREATE TEMP MACRO add_tax(p) AS p * 1.1;

SELECT name, add_tax(salary) AS total
FROM (
  VALUES ('Alice', 5000)
) t(name, salary);
