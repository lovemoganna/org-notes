CREATE TEMP TABLE tt AS SELECT *
FROM (
  VALUES (1, 'Alice'),
   (2, 'Bob')
) t(id, name);

SELECT *
FROM tt
ORDER BY id;
