CREATE TEMP TABLE tt AS SELECT *
FROM (
  VALUES (1, 'Alice'),
   (2, 'Bob')
) t(id, name);

SELECT *
FROM tt
ORDER BY id;

-- 补充检查
SELECT temporary FROM duckdb_tables() WHERE table_name = 'tt';
