PREPARE q AS SELECT *
FROM (
  VALUES (1, 'Alice'),
   (2, 'Bob')
) t(id, name)
WHERE id >= $1;

EXECUTE q(2);

DEALLOCATE q;
