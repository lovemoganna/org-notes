CREATE TEMP MACRO get_dept(d) AS TABLE
SELECT *
FROM (
  VALUES ('Sales', 'Alice'),
   ('Tech', 'Bob')
) t(dept, name)
WHERE dept = d;

SELECT *
FROM get_dept('Sales');
