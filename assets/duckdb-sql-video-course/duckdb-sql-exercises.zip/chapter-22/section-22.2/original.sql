CREATE TEMP VIEW tv AS SELECT *
FROM (
  VALUES (1, 'Alice'),
   (2, 'Bob')
) t(id, name);

SELECT *
FROM tv
ORDER BY id;
