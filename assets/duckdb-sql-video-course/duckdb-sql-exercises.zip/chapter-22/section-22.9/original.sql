ATTACH ':memory:' AS db1;

ATTACH ':memory:' AS db2;

SET search_path = 'db1,db2';
