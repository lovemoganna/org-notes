ATTACH ':memory:' AS db1;

ATTACH ':memory:' AS db2;

SET search_path = 'db1,db2';

-- 补充检查
SELECT current_setting('search_path') AS lookup_order;
