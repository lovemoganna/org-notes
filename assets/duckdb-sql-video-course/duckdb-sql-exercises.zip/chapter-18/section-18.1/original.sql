SELECT x
FROM (
  VALUES (1),
   (2),
   (3)
) t(x)
ORDER BY x
LIMIT 2
OFFSET 1;
