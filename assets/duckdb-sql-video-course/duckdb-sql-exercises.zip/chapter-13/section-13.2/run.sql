-- 补充：用内嵌数据生成原查询所需文件。
COPY (SELECT * FROM (VALUES (1, 'Alice'), (2, 'Bob')) AS t(id, name))
TO 'fixtures/users.parquet' (FORMAT PARQUET);

SELECT *
FROM read_parquet('fixtures/users.parquet');
