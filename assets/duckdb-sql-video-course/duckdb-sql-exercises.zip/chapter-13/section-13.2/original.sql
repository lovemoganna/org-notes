SELECT *
FROM read_parquet('fixtures/users.parquet');
