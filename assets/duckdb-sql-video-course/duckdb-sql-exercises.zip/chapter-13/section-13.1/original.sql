SELECT *
FROM read_csv('fixtures/users.csv');
