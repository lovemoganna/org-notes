SELECT COALESCE(l.id, r.id) AS id, l.name, r.dept
FROM (
  VALUES (1, 'Alice')
) l(id, name)
RIGHT JOIN (
  VALUES (1, 'Sales'),
   (2, 'Tech')
) r(id, dept) USING (id);
