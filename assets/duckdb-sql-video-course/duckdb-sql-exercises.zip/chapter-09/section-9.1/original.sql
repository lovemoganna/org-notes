SELECT l.id, l.name, r.bonus
FROM (
  VALUES (1, 'Alice'),
   (2, 'Bob')
) l(id, name)
INNER JOIN (
  VALUES (2, 800),
   (3, 500)
) r(id, bonus) USING (id);
