SELECT COALESCE(l.id, r.id) AS id, l.name, r.dept
FROM (
  VALUES (1, 'Alice'),
   (2, 'Bob')
) l(id, name)
FULL JOIN (
  VALUES (2, 'Tech'),
   (3, 'HR')
) r(id, dept) USING (id);
