SELECT DISTINCT dept
FROM (
  VALUES ('Sales'),
   ('Tech'),
   ('Sales'),
   ('Tech')
) t(dept);
