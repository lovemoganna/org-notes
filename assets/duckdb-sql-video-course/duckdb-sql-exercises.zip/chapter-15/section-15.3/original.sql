SELECT *
FROM (
  VALUES (1),
   (2),
   (3)
) a(id)
ANTI JOIN (
  VALUES (2),
   (3)
) b(id) USING (id);
