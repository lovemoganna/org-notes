SELECT *
FROM (
  VALUES (1),
   (2),
   (3)
) a(id)
SEMI JOIN (
  VALUES (2),
   (3)
) b(id) USING (id);
