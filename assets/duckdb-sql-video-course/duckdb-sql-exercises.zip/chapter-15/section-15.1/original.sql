SELECT *
FROM (
  VALUES (1),
   (2)
) a(x)
CROSS JOIN (
  VALUES ('A'),
   ('B')
) b(y);
