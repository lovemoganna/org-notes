SELECT dept, MIN(salary) AS min_sal
FROM (
  VALUES ('Sales', 5000),
   ('Sales', 6000),
   ('Tech', 7000)
) t(dept, salary)
GROUP BY dept;
