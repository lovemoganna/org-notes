SELECT dept
FROM (
  VALUES ('Sales'),
   ('Sales'),
   ('Tech')
) t(dept)
GROUP BY dept;
