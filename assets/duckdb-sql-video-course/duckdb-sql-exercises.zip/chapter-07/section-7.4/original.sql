SELECT dept, AVG(salary) AS avg_salary
FROM (
  VALUES ('Sales', 5000),
   ('Sales', 6000),
   ('Tech', 7000)
) t(dept, salary)
GROUP BY dept;
