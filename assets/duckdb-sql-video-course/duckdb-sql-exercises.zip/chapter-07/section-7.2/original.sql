SELECT dept, COUNT(*) AS head_count
FROM (
  VALUES ('Sales', 5000),
   ('Sales', 6000),
   ('Tech', 7000)
) t(dept, salary)
GROUP BY dept;
