WITH RECURSIVE t(n) AS (
  VALUES (1)
  UNION ALL
  SELECT n + 1
  FROM t
  WHERE n < 3
)
SELECT *
FROM t;
