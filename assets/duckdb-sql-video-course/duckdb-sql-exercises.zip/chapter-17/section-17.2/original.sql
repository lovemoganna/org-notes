WITH s(id, q1, q2) AS (
  VALUES (1, 10, 20)
)
SELECT *
FROM (
  UNPIVOT s ON q1,
  q2 INTO NAME quarter VALUE amount
);
