WITH s(item, q, amt) AS (
  VALUES ('A', 'Q1', 10),
   ('A', 'Q2', 20)
)
SELECT *
FROM (
  PIVOT s ON q USING SUM(amt)
  GROUP BY item
);
