VALUES (1, 'Alice', 'Sales'), (2, 'Bob', 'Tech'), (3, 'Charlie', 'Sales');
