SELECT x
FROM (
  VALUES (1),
   (2)
) AS t(x);
