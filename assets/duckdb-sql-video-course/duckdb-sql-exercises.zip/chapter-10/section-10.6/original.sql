SELECT *
FROM (
  VALUES (1),
   (1),
   (2),
   (3)
) t(x)
EXCEPT ALL
SELECT *
FROM (
  VALUES (1),
   (2)
) u(x);
