SELECT *
FROM (
  VALUES (1),
   (1),
   (2)
) t(x)
INTERSECT ALL
SELECT *
FROM (
  VALUES (1),
   (1),
   (1),
   (3)
) u(x);
