SELECT *
FROM (
  VALUES (1, 'Alice'),
   (2, 'Bob')
) t(id, name)
UNION ALL
SELECT *
FROM (
  VALUES (1, 'Alice'),
   (3, 'Charlie')
) u(id, name);
