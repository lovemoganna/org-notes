SELECT *
FROM (
  VALUES (1, 'Alice'),
   (2, 'Bob'),
   (3, 'Charlie')
) t(id, name)
EXCEPT
SELECT *
FROM (
  VALUES (1, 'Alice'),
   (2, 'Bob')
) u(id, name);
