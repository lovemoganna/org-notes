SELECT *
FROM (
  VALUES (1, 'Alice'),
   (2, 'Bob')
) t(id, name)
INTERSECT
SELECT *
FROM (
  VALUES (1, 'Alice'),
   (3, 'Charlie')
) u(id, name);
