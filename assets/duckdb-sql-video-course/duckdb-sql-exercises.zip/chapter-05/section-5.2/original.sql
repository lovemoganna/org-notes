SELECT *
FROM (
  VALUES ('Alice', 5000),
   ('Bob', 7000),
   ('Charlie', 6000)
) t(name, salary)
ORDER BY salary DESC
LIMIT 2;
