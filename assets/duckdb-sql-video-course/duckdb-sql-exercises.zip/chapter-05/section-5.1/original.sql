SELECT *
FROM (
  VALUES (2, 'Bob'),
   (1, 'Alice')
) t(id, name)
ORDER BY id ASC;
